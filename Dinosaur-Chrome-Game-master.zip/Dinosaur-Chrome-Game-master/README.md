# Dinosaur-Chrome-Game
A step by step clone of how to build the Dinosaur game found on Chrome No Internet Screen.
